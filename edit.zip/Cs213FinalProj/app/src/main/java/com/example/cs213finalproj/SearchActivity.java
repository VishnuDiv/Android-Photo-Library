package com.example.cs213finalproj;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import model.Album;
import model.Photo;
import model.Tag;


public class SearchActivity extends Activity {

    ArrayList<Album> albums;
    Album selectAlbum;

    Photo shownPhoto;
    ArrayList<Photo> addThisPhoto ;


    ArrayList<Tag> tags;
    ArrayList<String> tagList;
   RecyclerAdapter adapter;
    int listViewPosition;
    AutoCompleteTextView location_autoc;
    AutoCompleteTextView person_autoc;
   // ListView lv_search;
    Button s_button;
    ImageView image_select;
   // Album albumNames;
    ArrayList<String> albNames;
    ArrayList<String> photos;
    GridView search_g;
    int selected_idx;
    Photo current_p;
    ImageView i_search;
    ArrayList<Uri> searchResult;
    ArrayList<String> p_auto;
    ArrayList<String> l_auto;
    ArrayAdapter<String>p_adapt;
    ArrayAdapter<String> l_adapt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_activity);
        loadData();
        populate();
        location_autoc = findViewById(R.id.location_autoc);
        search_g=findViewById(R.id.grid_search);
        person_autoc = findViewById(R.id.person_autoc);
        i_search = findViewById(R.id.i_search);
        searchResult = new ArrayList<>();
        adapter = new RecyclerAdapter(this, searchResult);
        search_g.setAdapter(adapter);

      //  lv_search = findViewById(R.id.lv_search);

        s_button = findViewById(R.id.s_button);

        //image_select = findViewById(R.id.image_select);

       // albums = new ArrayList<>();
        albNames = new ArrayList<>();

        addThisPhoto = new ArrayList<>();

        photos = new ArrayList<>();
      p_adapt = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,p_auto);
        l_adapt = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,l_auto);
        location_autoc.setAdapter(l_adapt);
        person_autoc.setAdapter(p_adapt);

      //  lv_search.setAdapter(adapter);

//        for(int i = 0; i <addThisPhoto.size();i++ ){
//            photos.add(addThisPhoto.get(i).getPhoto());
//
//
//        }
//        for(int i = 0; i < albums.size();i++){
//            albNames.add(albums.get(i).getName());
//
//        }

//        lv_search.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> a, View v, int position,
//                                    long id) {
//
//                listViewPosition = position;
//           //     Log.d("777", shownPhoto.getFilePath());
//           //     image_select.setImageURI((Uri.parse(shownPhoto.getFilePath())));
//               lv_search.setSelection(position);
//                saveData();
//
//            }
//        });
        search_g.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
             i_search.setImageURI(searchResult.get(i));


            }
        });
    }
public void populate(){
        p_auto = new ArrayList<>();
        l_auto = new ArrayList<>();
    for(Album searchAlb: albums) {

        for (Photo searchP : searchAlb.getPhoto()) {

            for (Tag searchT : searchP.getTag()) {

                String tagsVal = searchT.getTagValue();
                String tagName = searchT.getTagName();
                if(tagName.equals("person")) {
                    if (!p_auto.contains(tagsVal)) {


                        p_auto.add(tagsVal);
                        Log.d("999",tagsVal);
                    }
                }
                if(tagName.equals("location")) {
                    if (!l_auto.contains(tagsVal)) {


                        l_auto.add(tagsVal);
                    }
                }
            }
        }
    }
}
    @Override
    public void onBackPressed() {

        saveData();
        loadData();


        Intent myIntent = new Intent(this, MainActivity.class);
        startActivity(myIntent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    public void searchTags(View view){
        loadData();
    String search_person = person_autoc.getText().toString();
    String search_location = location_autoc.getText().toString();
    Log.d("444",search_person);

    if(search_person!=null || search_location!=null){
        addThisPhoto.clear();
        for(Album searchAlb: albums){
            Log.d("111", searchAlb.getName());
            for(Photo searchP: searchAlb.getPhoto()){
                Log.d("222",searchP.getFilePath());
                ArrayList<String> l= new ArrayList<>();

                ArrayList<Tag> l_r = searchP.getTag();
                ArrayList<String> p= new ArrayList<>();
                for(Tag m : searchP.getTag()){
                    if(m.getTagName().equals("person")){
                        p.add(m.getTagValue());
                        //p.stream().anyMatch(""::equalsIgnoreCase );

                    }
                    else if(m.getTagName().equals("location")){
                        l.add(m.getTagValue());
                      //  l.stream().anyMatch(""::equalsIgnoreCase );

                    }
                }
                for(Tag searchT: searchP.getTag()){
                    Log.d("333", searchT.tagValue);
                String tagsVal = searchT.getTagValue();



                    if(p.contains(search_person) && l.contains(search_location)){
                        addThisPhoto.add(searchP);
                        //  photos.add(search_person);
                        //    photos.add(search_location);
                        // image_select.setImageURI(Uri.parse(searchP.getFilePath()));
                        //searchP = current_p;
                    }
                else if(tagsVal.equalsIgnoreCase(search_person) && search_location.isEmpty()){
                    addThisPhoto.add(searchP);
                  //  photos.add(search_person);
                   // image_select.setImageURI(Uri.parse(searchP.getFilePath()));
                   // searchP = current_p;
                }
                else if(tagsVal.equalsIgnoreCase(search_location) && search_person.isEmpty()){
                    addThisPhoto.add(searchP);
                   // photos.add(search_location);
                  //  image_select.setImageURI(Uri.parse(searchP.getFilePath()));

                    Log.d("000",searchP.getFilePath());
                  //  shownPhoto = searchP;
                    Log.d("tp", shownPhoto.getFilePath());
                   // searchP = current_p;
                }




                }

                }
            }
        searchResult.clear();
        for(int i = 0; i < addThisPhoto.size();i++){
           searchResult.add(Uri.parse(addThisPhoto.get(i).getFilePath()));
        }


    }
    adapter.notifyDataSetChanged();
    //saveData();


    }



    private void saveData() {

        for(int i = 0; i < albums.size(); i++){
            if(albums.get(i).albumName.equals(selectAlbum.albumName)){
                Log.d("Updated Album", albums.get(i).albumName);
                albums.set(i, selectAlbum);
            }
        }

        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(albums);
        editor.putString("album list", json);

        String json2 = gson.toJson(selectAlbum);
        editor.putString("selectedAlbum", json2);

        String json3 = gson.toJson(shownPhoto);
        editor.putString("selectedPhoto", json3);


        editor.putInt("selectedIndex", selected_idx);


        editor.apply();
    }


    private void loadData() {
        SharedPreferences sharedPreferences = getSharedPreferences("shared preferences", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("album list", null);
        Type type = new TypeToken<ArrayList<Album>>() {}.getType();
        albums = gson.fromJson(json, type);

        if (albums == null) {
            albums = new ArrayList<>();
        }

        String json2 = sharedPreferences.getString("selectedAlbum", "");
        selectAlbum = gson.fromJson(json2, Album.class);

        String json3 = sharedPreferences.getString("selectedPhoto", "");
        shownPhoto = gson.fromJson(json3, Photo.class);

        if (shownPhoto == null) {
            shownPhoto = new Photo("","");
        }

        selected_idx  = sharedPreferences.getInt("selectedIndex", 0);


    }

}
